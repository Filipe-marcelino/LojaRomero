from flask import Flask, render_template, request, redirect, make_response, url_for, session, flash
# from flask_session import Session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'MEGADIFICIL_ME_ESCONDE'

usuarios = {}
lista_produtos = [
    {'id': 1, 'nome': 'Senhor dos Anéis', 'preco': 35},
    {'id': 2, 'nome': 'Harry Potter', 'preco': 35},
    {'id': 3, 'nome': 'Nárnia', 'preco': 20},
    {'id': 4, 'nome': 'Sherlock Holmes', 'preco': 25}
] 

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/cadastro', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        nome = request.form.get('nome')
        senha = request.form.get('senha')

        senha_criptografada = generate_password_hash(senha)

        if nome not in usuarios:         
            usuarios[nome] = senha_criptografada
            flash("Cadastro realizado com sucesso!")
            return redirect(url_for('login'))
        if nome in usuarios and check_password_hash(usuarios[nome], senha):
            flash("Você já está cadastrado")
            return redirect(url_for('login'))

    return render_template('cadastro.html')

@app.route('/login', methods=['POST', 'GET'])
def login():

    if request.method == 'POST':
        nome = request.form.get('nome')
        senha = request.form.get('senha')
        senha_criptografada = generate_password_hash(senha)

        if nome not in usuarios:
            return redirect(url_for('register'))
        if nome in usuarios and check_password_hash(usuarios[nome], senha):
            # logar o usuário
            session['user'] = nome
            session['senha_criptografada'] = senha_criptografada
            return redirect(url_for('produtos'))
        else:
            return redirect(url_for('register'))

    return render_template('login.html')

@app.route('/logout', methods=["POST"])
def logout():
    session.pop('usuario', None)
    session.pop('carrinho', None)
    return redirect(url_for('index'))

@app.route('/produtos', methods=["GET", "POST"])
def produtos():
    if 'nome' not in session:
        return redirect(url_for('register'))

    if request.method == 'POST':
        # getlist -- pega vários valores dos produtos selecionados com o mesmo nome 'produto_id' no formulário HTML
        selecionados = request.form.getlist('produto_id')
        selecionados_convertidos = []

        # Converte para uma lista de inteiros
        for id in selecionados:
            numero = int(id)
            selecionados_convertidos.append(numero)
            print(selecionados_convertidos)

        # Busca os produtos pelos IDs. Tenta recuperar o carrinho atual da sessão, se estiver vazio cria ([]) por padrão
        carrinho = session.get('carrinho', [])
        # Adiciona os produtos recém-selecionados ao carrinho.
        carrinho.extend(selecionados)

        # Salva o carrinho atualizado de volta na sessão.
        session['carrinho'] = carrinho

        return redirect(url_for('carrinho'))

    return render_template('produtos.html', produtos=lista_produtos)

@app.route('/carrinho')
def carrinho():
    return render_template('carrinho.html')


if __name__ == "__main__":
    app.run(debug=True)

